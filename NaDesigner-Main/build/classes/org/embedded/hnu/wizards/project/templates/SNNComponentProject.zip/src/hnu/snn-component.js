module.exports = function(NAIDE) {
    function SNNComponent(config) {
        NAIDE.components.createComponent(this,config);
        var component = this;
        component.on('input', function(msg) {
            msg.payload = msg.payload.toSnnComponent();
            component.send(msg);
        });
    }
    NAIDE.components.registerType("snn-component",SNNComponent);
}
